<template>
    <div :class="
      this.$store.state.theme === 'dark'
        ? 'dark h-screen w-screen p-4 px-10'
        : ' h-screen w-screen p-4 px-10'
    ">
    {{this.$store.state.lang==='en'? 'Reports':'التقارير'}}
    
    </div>
</template>
<style scoped>
.dark {
  background-color: #1a1a1a;
  color: rgb(255, 255, 255);
}
</style>