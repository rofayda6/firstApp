<script>
/*eslint-disable */
export default {
    data() {
        
    },
}
</script>
<template>
    <div class="lead">

    </div>
</template>