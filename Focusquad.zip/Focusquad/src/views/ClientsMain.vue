<template>
    <div class="temp">
    <router-view></router-view>
    </div>
</template>