<script>
export default {};
</script>
<template>
  <div class="wrapping-circle rounded-full bg-[#C9C9C9] mt-1.5 p-0.5 h-1"></div>
</template>