<script>
export default {
  props: ["placeHolderValue", "options", "valueKey", "nameKey"],
};
</script>

<template>
  <select
    :class="
      this.$store.state.theme === 'dark'
        ? 'wrapping-text-box bg-[#3c3c3c] outline-none cursor-pointer focus:border-blue-600 border w-full border-[#656565] rounded-lg placeholder:text-[#C7C7C7] text-white p-2'
        : 'wrapping-text-box bg-[#F9F9F9] outline-none focus:border-blue-600 border w-full border-[#E1E1E1] cursor-pointer rounded-lg placeholder:text-[#C7C7C7] text-black p-2'
    "
  
    >
    <option class="text-sm" :value="placeHolderValue">
      {{ placeHolderValue }}
    </option>
    <option
      class="text-black text-sm"
      v-for="opt in options"
      :key="opt.id"
      :value="opt[valueKey]"
    >
      {{ opt[nameKey] }}
    </option>
  </select>
</template>
  <!--
    class="bg-[#F9F9F9] text-xs outline-none focus:border-blue-600 placeHolderValue:text-[#C7C7C7] rounded-lg text-[#C7C7C7] cursor-pointer p-2 w-full h-8 border border-[#E1E1E1]"
    -->