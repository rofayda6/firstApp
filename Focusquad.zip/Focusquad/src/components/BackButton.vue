<script>
/*eslint-diable*/
export default {};
</script>
<template>
  <div
    class="h-8 w-8 bg-[#EFEFEF] rounded-lg cursor-pointer border border-[#B3B3B3] text-[#686868]"
  >
    

    <svg
      xmlns="http://www.w3.org/2000/svg"
      fill="none"
      viewBox="0 0 24 24"
      stroke-width="1.5"
      stroke="currentColor"
      class="w-4 h-4 mt-[7px] mx-[7px]"
    >
      <path
        stroke-linecap="round"
        stroke-linejoin="round"
        d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18"
      />
    </svg>
  </div>
</template>