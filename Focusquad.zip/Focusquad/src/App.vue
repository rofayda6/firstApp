<script setup>
import { RouterView } from "vue-router";
</script>

<template>
  <div class="main wrapper w-screen h-screen overflow-hidden bg-[#F6F6F6]" :style="this.$store.state.lang==='ar' ? 'direction:rtl':''">
    <RouterView />
  </div>
</template>